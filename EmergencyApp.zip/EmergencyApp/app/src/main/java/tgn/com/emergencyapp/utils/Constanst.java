package tgn.com.emergencyapp.utils;

public class Constanst {
    public static final String PUSH_NOTIFICATION = "http://192.168.137.22/emergencyapp/api/notification/create.php";
    public static final String FETCH_NOTIFICATION = "http://192.168.137.22/emergencyapp/api/notification/read.php";



    public static final String BLOOD_REQ = "http://192.168.137.22/emergencyapp/api/bloodnotification/create.php";
    public static final String BLOOD_FETCH = "http://192.168.137.22/emergencyapp/api/bloodnotification/read.php";


    public static final String COMMUNITY_NOT_PUSH = "http://192.168.137.22/emergencyapp/api/community/create.php";
    public static final String COMMUNITY_NOT_PULL = "http://192.168.137.22/emergencyapp/api/community/read.php";

    public static final String USER_CREATE = "http://192.168.137.22/emergencyapp/api/users/create.php";
}
