package tgn.com.emergencyapp.models;

public class emModel {
    public static String content;
    public static String title;
}
